package com.msk.smartparkingadmin;

import com.msk.qrcode.CaptureActivity;

import com.msk.web.WebWrapper;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	
	

	public void getBooking(View v)
	{
		Intent i = new Intent(this, BookingActivity.class);
		startActivity(i);
		
	}
	
	public void scanQR(View v)
	{
		boolean entry =false;
		switch(v.getId())
		{
		case R.id.button2:
			entry = true; //entry
			break;
		case R.id.button3:
			entry = false; //exit
			break;
		}
		Intent i = new Intent(this, CaptureActivity.class);
		i.putExtra("Entry", entry);
		startActivity(i);
		
	}
}
