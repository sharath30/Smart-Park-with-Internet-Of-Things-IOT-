package com.msk.smartparkingadmin;

import com.msk.web.WebWrapper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class LoginActivity extends Activity implements AdapterView.OnItemSelectedListener {
	
	private EditText loginE, passE;
	private String ipServer;
	private Spinner areaSp;
	private int areaCode;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		areaSp = (Spinner) findViewById(R.id.spinner);
		areaSp.setOnItemSelectedListener(this);
		loginE = (EditText) findViewById(R.id.loginE);
		passE = (EditText) findViewById(R.id.passE);
		
		readIP();
	}
	
	private void readIP()
	{
		SharedPreferences pref = getSharedPreferences(
				"number", MODE_PRIVATE);
		ipServer = pref.getString("ip", null);
		if(ipServer==null)
			displayIP();
		else
			WebWrapper.setUrls(ipServer);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		menu.add(0,2,0,"Server IP");

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		displayIP();
		return true;
	}
	
	private Dialog displayIP() {
		LayoutInflater factory = LayoutInflater.from(this);
		final View textEntryView = factory.inflate(R.layout.ip_dialog,
				null);
		final EditText numberE = (EditText) textEntryView
				.findViewById(R.id.numberE);
		SharedPreferences pref = getSharedPreferences("number",
				MODE_PRIVATE);
		String set_number = pref.getString("ip", "");
		numberE.setText(set_number);
		return new AlertDialog.Builder(this)
				.setIcon(android.R.drawable.alert_dark_frame)
				.setTitle("Enter server IP address")
				.setView(textEntryView)
				.setCancelable(false)
				.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {

								/* User clicked OK so do some stuff */
								String number = numberE.getText()
										.toString();

								if (number.length() <=0) {

									Toast.makeText(LoginActivity.this,
											"Enter valid IP",
											Toast.LENGTH_LONG).show();

								} else {
									// mobile_number = number;
									SharedPreferences pref = getSharedPreferences(
											"number", MODE_PRIVATE);
									SharedPreferences.Editor editor = pref
											.edit();
									editor.putString("ip", number);
									editor.commit();
									WebWrapper.setUrls(number);
									WebWrapper.ip= number;
									dialog.cancel();
								}
							}
						})

				.show();

		
	}

	public void onlogin(View v)
	{
		String login = loginE.getText().toString();
		String password = passE.getText().toString();
		
		// do login
		// after success
		//save to sharedPref and launch next activity
		if(login.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin"))
		{
		
		SharedPreferences pref = getSharedPreferences("auth", MODE_PRIVATE);
		SharedPreferences.Editor editor= pref.edit();
		editor.putString("username", login);
		editor.putString("password", password);
			editor.putInt("area",areaCode);
		editor.commit();
		
		Intent i = new Intent(this, MainActivity.class);
		startActivity(i);
		}
		else
			Toast.makeText(this, "Authentication failed", Toast.LENGTH_LONG).show();
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		areaCode =position;
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {

	}
}
