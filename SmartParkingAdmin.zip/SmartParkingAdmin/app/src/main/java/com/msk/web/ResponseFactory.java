package com.msk.web;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;

import com.msk.smartparkingadmin.BookingManager;
import com.msk.smartparkingadmin.BookingManager.Booking;
import com.msk.smartparkingadmin.BookingManager.BookingCharge;

public class ResponseFactory {

	public static boolean error=false;
	public static String getBookingStatus(Context ctx,JSONObject result) {

		String status=null;
		try {
			error=result.getBoolean("error");
			status=result.getString("message");
			if(!error)
			{
				String qrcodePath = result.getString("qrcodeurl");
				
				//downloadFile(ctx,qrcodePath);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
		
	}
	
	public static void getBooking(JSONObject result,int areaCode) {
		ArrayList<Booking> list = new ArrayList<Booking>();
		
		try {
			JSONArray array = result.getJSONArray("bookingdata");
			
			for(int i=0; i<array.length(); i++)
			{
				JSONObject obj = array.getJSONObject(i);
				Booking booking = new Booking();
				booking.slot_no = obj.getInt("slotnumber");
				
				String startTime = obj.getString("starttime");
				String[] fields=startTime.split(":");
				
				booking.start_hour = Integer.parseInt(fields[0]);
				booking.start_min = Integer.parseInt(fields[1]);
				
				String endTime = obj.getString("endtime");
				fields=endTime.split(":");
				
				booking.exit_hour = Integer.parseInt(fields[0]);
				booking.exit_min = Integer.parseInt(fields[1]);
				booking.isAvailable = false;
				
				list.add(booking);
				
			}
			
			BookingManager.setBooking(list,areaCode);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
public static String cancelBooking(JSONObject result) {
		
		String status=null;
		try {
			error=result.getBoolean("error");
			status=result.getString("message");
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}

public static String entryExitResponse(JSONObject result)
{
	String status=null;
	try {
		error=result.getBoolean("error");
		status=result.getString("message");
		
		if(!error)
		{
			BookingCharge charge = new BookingCharge();
			charge.delay = result.getString("delay");
			charge.duration = result.getInt("duration");
			charge.hourlyRate = result.getDouble("hourlyrate");
			charge.delayCharge = result.getDouble("delaycharge");
			charge.bookingCharge = result.getDouble("bookingcharge");
			charge.totleCharge = result.getDouble("totalprice");
			
			BookingManager.setCharge(charge);
		}
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return status;
}
}
