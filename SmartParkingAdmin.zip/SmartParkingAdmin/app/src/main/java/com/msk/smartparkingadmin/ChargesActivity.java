package com.msk.smartparkingadmin;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TextView;

public class ChargesActivity extends Activity {

	private TextView durationT, delayT, rateT, amountT;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_charges);
		
		durationT = (TextView) findViewById(R.id.durationT);
		delayT = (TextView) findViewById(R.id.delayT);
		rateT = (TextView) findViewById(R.id.rateT);
		amountT = (TextView) findViewById(R.id.amountT);
		
		Intent i = getIntent();
		int duration = i.getIntExtra("duration", 0);
		double delay = i.getDoubleExtra("delay", 0.0);
		double rate = i.getDoubleExtra("hRate", 0);
		double amount = i.getDoubleExtra("totalCharge", 0);
		
		durationT.setText(""+duration+" min");
		delayT.setText(""+delay + " Rs");
		rateT.setText(""+rate + " Rs");
		amountT.setText(""+amount + " Rs");
	}

	

}
