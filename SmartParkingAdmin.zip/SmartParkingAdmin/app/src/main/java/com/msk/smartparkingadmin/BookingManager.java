package com.msk.smartparkingadmin;

import java.util.ArrayList;

import com.msk.smartparkingadmin.BookingManager.BookingCharge;

public class BookingManager {
	
	public static class Booking
	{
		public int slot_no;
		public boolean isAvailable;
		public int start_hour;
		public int start_min;
		public int exit_hour;
		public int exit_min;
	}
	
	public static class BookingCharge
	{
		public String delay;
		public int duration;
		public double hourlyRate;
		public double delayCharge;
		public double bookingCharge;
		public double totleCharge;
		
	}

	public static int adjustIndex(int area)
	{
		switch(area)
		{
			case 0:
				return 0;
			case 1:
				return 8;
			case 2:
				return 16;
			case 3:
				return 24;
		}
		return 0;
	}
	private static ArrayList<Booking> bookingList= new ArrayList<Booking>();

	public static void setBooking(ArrayList<Booking> list, int area)
	{
		int area_index = adjustIndex(area);
		ArrayList<Booking> arrangedList = new ArrayList<BookingManager.Booking>();
		for(int i =0; i<8; i++)
		{
			int slot= i+1+area_index;
			int match = -1;
			for(int j=0; j<list.size(); j++)
			{
				Booking booking = list.get(j);
				if(booking.slot_no == slot)
				{
					match = j;
					break;
				}
			}

			if(match!=-1)
				arrangedList.add(list.get(match));
			else
			{
				Booking booking = new Booking();
				booking.slot_no = slot;
				booking.isAvailable = true;
				arrangedList.add(booking);
			}

		}
		bookingList = arrangedList;
	}

	public static boolean isAvailable(int slot_no, int area)
	{
		int area_index = adjustIndex(area);

		int index = slot_no -1-area_index;

		return bookingList.get(index).isAvailable;
	}

	public static int getStartH(int slot_no,int area)
	{
		int area_index = adjustIndex(area);

		int index = slot_no -1-area_index;
		return bookingList.get(index).start_hour;
	}

	public static int getStartM(int slot_no,int area)
	{
		int area_index = adjustIndex(area);

		int index = slot_no -1-area_index;
		return bookingList.get(index).start_min;
	}

	//private static ArrayList<Booking> bookingList= new ArrayList<Booking>();
	private static BookingCharge charge;


	public static void setCharge(BookingCharge charge1) {
		// TODO Auto-generated method stub
		charge = charge1;
	}
	
	public static BookingCharge getCharge()
	{
		return charge;
	}
}
