package com.msk.smartparkingadmin;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;


import com.msk.web.RequestFactory;
import com.msk.web.ResponseFactory;
import com.msk.web.WebWrapper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

public class BookingActivity extends Activity implements OnItemSelectedListener, OnTimeSetListener {

	private EditText vehicleE, mobileE;
	private RadioGroup typeR;
	private Spinner levelS;
	private Button slot1, slot2, slot3, slot4, slot5, slot6, slot7, slot8;
	private int level, type;
	private GridLayout gl;
	private String mobile;
	private String vehicleNo;
	private int slotNo;
	private int areaCode;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.booking);

		SharedPreferences pref = getSharedPreferences("auth", MODE_PRIVATE);
		areaCode=pref.getInt("area",0);

		gl = (GridLayout) findViewById(R.id.gridLayout1);
		gl.setVisibility(View.GONE);
		slot1 = (Button) findViewById(R.id.button1);
		slot2 = (Button) findViewById(R.id.button2);
		slot3 = (Button) findViewById(R.id.button3);
		slot4 = (Button) findViewById(R.id.button4);
		slot5 = (Button) findViewById(R.id.button5);
		slot6 = (Button) findViewById(R.id.button6);
		slot7 = (Button) findViewById(R.id.button7);
		slot8 = (Button) findViewById(R.id.button8);

		vehicleE = (EditText) findViewById(R.id.loginE);
		mobileE = (EditText) findViewById(R.id.mobileE);
		typeR = (RadioGroup) findViewById(R.id.radioGroup1);
		levelS = (Spinner) findViewById(R.id.spinner1);

		levelS.setOnItemSelectedListener(this);
		setSlotTitles();
	}

	private void setSlotTitles() {
		if(areaCode!=0)

		{
			int area_index = BookingManager.adjustIndex(areaCode);
			slot1.setText(1+area_index+"");
			slot2.setText(2+area_index+"");
			slot3.setText(3+area_index+"");
			slot4.setText(4+area_index+"");
			slot5.setText(5+area_index+"");
			slot6.setText(6+area_index+"");
			slot7.setText(7+area_index+"");
			slot8.setText(8+area_index+"");
		}
	}
	public void doBooking(View v) {
		vehicleNo = vehicleE.getText().toString();
		mobile = mobileE.getText().toString();
		if (vehicleNo.length() > 0) {
			CharSequence slotS = ((Button) v).getText();

			slotNo = Integer.parseInt(slotS.toString());

			boolean isAvailable = BookingManager.isAvailable(slotNo,areaCode);

			if (isAvailable) {
				if(mobile.length()>0)
				{
					
					TimePickerDialog dlg = new TimePickerDialog(this, this, 8, 0, true);
					dlg.setTitle("Select time");
					dlg.show();
				}
				else
					Toast.makeText(this, "Pls enter mobile number", Toast.LENGTH_LONG).show();
			} else {
				// show Dialog for cancellation or another booking
				displayDialog(1, slotNo);
			}

		} else
			Toast.makeText(this, "Pls enter vehicle number", Toast.LENGTH_LONG)
					.show();
	}

	private void displayDialog(int i, final int slotNo) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		switch (i) {
		case 1:
			builder.setMessage("Do you want to cancel this booking?");
			builder.setPositiveButton("Yes",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// cancel the booking
							CancelTask task = new CancelTask();
							task.execute(vehicleNo);

						}
					});

			builder.setNegativeButton("No",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {

							dialog.cancel();
						}
					});

			builder.setNeutralButton("Make Another booking",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {

							dialog.cancel();
							if(mobile.length()>0)
							{
							Intent i = new Intent(BookingActivity.this,
									BookingOverlapActivity.class);
							i.putExtra("type", type);
							i.putExtra("level", level);
							i.putExtra("slot", slotNo);
							i.putExtra("mobile", mobile);
							i.putExtra("vehicle", vehicleNo);
							startActivity(i);
							}
							else
								Toast.makeText(BookingActivity.this, "Pls enter mobile number", Toast.LENGTH_LONG).show();

						}
					});
			
			builder.show();

		}
	}

	private void setColor() {
		Button slotB = null;
		int area_index = BookingManager.adjustIndex(areaCode);
		for (int i = 1; i <= 8; i++) {
			switch (i) {
			case 1:
				slotB = slot1;
				break;
			case 2:
				slotB = slot2;
				break;
			case 3:
				slotB = slot3;
				break;
			case 4:
				slotB = slot4;
				break;
			case 5:
				slotB = slot5;
				break;
			case 6:
				slotB = slot6;
				break;
			case 7:
				slotB = slot7;
				break;
			case 8:
				slotB = slot8;
				break;
			}

			boolean isBooked = BookingManager.isAvailable(i+area_index,areaCode);
			if (!isBooked)
				slotB.setBackgroundResource(R.color.booked);
			else
				slotB.setBackgroundResource(R.color.available);
		}
	}

	private ProgressDialog dlg;
	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int position,
			long arg3) {

		level = position + 1;
		int id = typeR.getCheckedRadioButtonId();
		if (id == R.id.radio0)
			type = 1;
		else
			type = 2;// 4wheeler

		dlg = ProgressDialog.show(this, "", "Pls wait; getting status");
		// get booking Status
		 BookingStatus task = new BookingStatus();
		 task.execute(type, level);
		
		
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTimeSet(TimePicker arg0, int hod, int mm) {
		int currentH= Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		int currentM = Calendar.getInstance().get(Calendar.MINUTE);
		
		if(hod> currentH)
		{
			int diff = hod - currentH;
			if(diff>4)
				Toast.makeText(this, "Pls book 4hours before", Toast.LENGTH_LONG).show();
			else 
			{
				//do booking
				dlg = ProgressDialog.show(this, "", "Pls wait; Booking is in progress");
				BookingTask task = new BookingTask(vehicleNo, mobile, hod, mm, 0, 0);
				task.execute(level, type, slotNo);
			}
		}
		
		else
		{
			Toast.makeText(this, "Invalid booking time", Toast.LENGTH_LONG).show();
		}
	
		
	}
	
	private void setColor(int slot, boolean isBooked)
	{
		Button slotB=null;
		switch(slot)
		{
		case 1:
			slotB = slot1;
			break;
		case 2:
			slotB = slot2;
			break;
		case 3:
			slotB = slot3;
			break;
		case 4:
			slotB = slot4;
			break;
		case 5:
			slotB = slot5;
			break;
		case 6:
			slotB = slot6;
			break;
		case 7:
			slotB = slot7;
			break;
		case 8:
			slotB = slot8;
			break;
		}
		
		if(isBooked)
			slotB.setBackgroundResource(R.color.booked);
		else
			slotB.setBackgroundResource(R.color.available);
	}
	private class BookingStatus extends AsyncTask<Integer, Void, JSONObject>
	{

		@Override
		protected JSONObject doInBackground(Integer... params) {
			
			JSONObject result=null;
			int type = params[0];
			int level = params[1];
			
			String typeS = WebWrapper.getTypeCode(type);
			
			
			String levelS = WebWrapper.getLevelCode(level);
			
			
			String url = WebWrapper.urlS +"/"+levelS+"/"+typeS;
			
			String response= WebWrapper.connectAndGetResponse(url, null, "GET");
			
			if(response !=null)
				try {
					result = new JSONObject(response);
				} catch (JSONException e) {
					Log.e("BookingActivity", e.getMessage());
				}
			
			return result;
		}
		
		@Override
		protected void onPostExecute(JSONObject result) {
			dlg.cancel();
			if(result!=null)
			{
				ResponseFactory.getBooking(result,areaCode);
				gl.setVisibility(View.VISIBLE);
				setColor();
			}
		}
		
	}
	
	private class BookingTask extends AsyncTask<Integer, Void, JSONObject>
	{
		private String vehicle, mobileNo;
		private int startH, startM, exitH, exitM;
		public BookingTask(String vehicle,String mobileNo, int startH, int startM, int exitH, int exitM) {
			this.vehicle = vehicle;
			this.mobileNo = mobileNo;
			this.startH = startH;
			this.startM = startM;
			this.exitH = exitH;
			this.exitM = exitM;
		}
		@Override
		protected JSONObject doInBackground(Integer... params) {
			JSONObject result=null;
			int level = params[0];
			int type = params[1];
			int slot = params[2];
			
			String typeS = WebWrapper.getTypeCode(type);
				
			String levelS = WebWrapper.getLevelCode(level);
			
			String url = WebWrapper.urlS +"/"+levelS+"/"+typeS+"/"+slot;

			HashMap<String, String> reqParams = RequestFactory.getBookingRequestParams(vehicle, mobileNo, startH, startM, exitH, exitM);
			String response= WebWrapper.connectAndGetResponse(url, reqParams, "POST");
			
			if(response !=null)
				try {
					result = new JSONObject(response);
				} catch (JSONException e) {
					Log.e("BookingActivity", e.getMessage());
				}
			
			return result;
		}
		
		@Override
		protected void onPostExecute(JSONObject result) {
			dlg.cancel();
			String status=null;
			if(result!=null)
			{
				status=ResponseFactory.getBookingStatus(BookingActivity.this, result);
				Toast.makeText(BookingActivity.this, "Status:"+status, Toast.LENGTH_LONG).show();
				if(!ResponseFactory.error)
					setColor(slotNo, true);
			}
				
		}
		
	}
	private class CancelTask extends AsyncTask<String, Void, JSONObject>
	{

		@Override
		protected JSONObject doInBackground(String... params) {
			JSONObject result=null;
			String vehicleNo = params[0];
			
			String url = WebWrapper.urlS +"/"+vehicleNo;
			
			String response= WebWrapper.connectAndGetResponse(url, null, "DELETE");
			
			if(response !=null)
				try {
					result = new JSONObject(response);
				} catch (JSONException e) {
					Log.e("BookingActivity", e.getMessage());
				}
			
			return result;
		}
		
		@Override
		protected void onPostExecute(JSONObject result) {
			if(result!=null)
			{
				String status=ResponseFactory.cancelBooking(result);
				Toast.makeText(BookingActivity.this, "Status:"+status, Toast.LENGTH_LONG).show();
				
			}
		}
	}
}
