

package com.msk.qrcode.result;

import android.app.Activity;
import android.widget.Toast;

import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;
import com.msk.smartparkingadmin.R;

/**
 * This class handles TextParsedResult as well as unknown formats. It's the fallback handler.
 *
 * 
 */
public final class TextResultHandler extends ResultHandler {
	private Activity activity;
	
  private static final int[] buttons = {
     
      R.string.button_ok
      
  };

  public TextResultHandler(Activity activity, ParsedResult result, Result rawResult) {
    super(activity, result, rawResult);
    this.activity = activity;
  }

  @Override
  public int getButtonCount() {
    return  buttons.length ;
  }

  @Override
  public int getButtonText(int index) {
    return buttons[index];
  }

  @Override
  public void handleButtonPress(int index) {
    String text = getResult().getDisplayResult();
    switch (index) {
      case 0:
        Toast.makeText(activity, text, Toast.LENGTH_LONG).show();
        
        // parse text 
        
        
        break;
      
      
    }
  }

  @Override
  public int getDisplayTitle() {
    return R.string.result_text;
  }
  
  
}
