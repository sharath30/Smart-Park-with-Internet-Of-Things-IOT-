package com.msk.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



public class RequestFactory {
	

	public static final HashMap<String, String> getBookingRequestParams(String vehicleNo, String mobileNo, int startH, int startM, int exitH, int exitM)
	{
		HashMap<String, String> params = new HashMap<>();
		params.put("starttime", startH + ":" + startM);
		params.put("endtime", exitH + ":" + exitM);
		params.put("vehiclenumber", vehicleNo);
		params.put("mobilenumber", mobileNo);
		return params;
	}
	
	public static final HashMap<String, String> getEntryExitParams(String level, String type, String slot, String vehicleNo, String mobileNo, String startT, String exitT)
	{
		HashMap<String, String> params = new HashMap<>();
		params.put("starttime", startT);
		params.put("endtime", exitT);
		params.put("vehiclenumber", vehicleNo);
		params.put("mobilenumber", mobileNo);
		params.put("slotnumber", slot);
		params.put("vehicletype", type);
		params.put("levelcode", level);
		
		return params;
	}


	
}
