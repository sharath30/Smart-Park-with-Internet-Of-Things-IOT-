package com.msk.smartparking;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


import org.json.JSONException;
import org.json.JSONObject;


import com.msk.web.RequestFactory;
import com.msk.web.ResponseFactory;
import com.msk.web.WebWrapper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

public class BookingActivity extends Activity implements OnTimeSetListener {
	
	private ProgressDialog dlg;
	private EditText vehicleE;
	private String vehicleNo=null, mobileNo=null;
	private int slotNo=1;
	private Button slot1, slot2, slot3,slot4,slot5, slot6, slot7, slot8;
	private int type, level, areaCode;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.booking);

		//BookingManager.setAlarm(this, 13, 05);

		vehicleE = (EditText) findViewById(R.id.vehicleE);
		slot1 = (Button) findViewById(R.id.button1);
		slot2 = (Button) findViewById(R.id.button2);
		slot3 = (Button) findViewById(R.id.button3);
		slot4 = (Button) findViewById(R.id.button4);
		slot5 = (Button) findViewById(R.id.button5);
		slot6 = (Button) findViewById(R.id.button6);
		slot7 = (Button) findViewById(R.id.button7);
		slot8 = (Button) findViewById(R.id.button8);
		
		SharedPreferences pref = getSharedPreferences(
				"number", MODE_PRIVATE);
		
		mobileNo = pref.getString("number", null);
		
		
		Intent i = getIntent();
		
		 type = i.getIntExtra("type", 1);
		 level = i.getIntExtra("level", 1);
		areaCode = i.getIntExtra("area",0);
		
		dlg = ProgressDialog.show(this, "Getting Booking status", "Please wait");
		// get booking status
		 BookingStatus task = new BookingStatus();
		 task.execute(type, level);

		setSlotTitles();
	}

	private void setSlotTitles() {
		if(areaCode!=0)

		{
			int area_index = BookingManager.adjustIndex(areaCode);
			slot1.setText(1+area_index+"");
			slot2.setText(2+area_index+"");
			slot3.setText(3+area_index+"");
			slot4.setText(4+area_index+"");
			slot5.setText(5+area_index+"");
			slot6.setText(6+area_index+"");
			slot7.setText(7+area_index+"");
			slot8.setText(8+area_index+"");
		}
	}

	private class BookingTask extends AsyncTask<Integer, Void, JSONObject>
	{
		private String vehicle, mobileNo;
		private int startH, startM, exitH, exitM;
		public BookingTask(String vehicle,String mobileNo, int startH, int startM, int exitH, int exitM) {
			this.vehicle = vehicle;
			this.mobileNo = mobileNo;
			this.startH = startH;
			this.startM = startM;
			this.exitH = exitH;
			this.exitM = exitM;
		}
		@Override
		protected JSONObject doInBackground(Integer... params) {
			JSONObject result=null;
			int level = params[0];
			int type = params[1];
			int slot = params[2];
			
			String typeS = WebWrapper.getTypeCode(type);
				
			String levelS = WebWrapper.getLevelCode(level);
			
			String url = WebWrapper.urlS +"/"+levelS+"/"+typeS+"/"+slot;
		//	url="http://192.168.1.2/trial/trial.php";

			HashMap<String, String> reqParams = RequestFactory.getBookingRequestParams(vehicle, mobileNo, startH, startM, exitH, exitM);
			String response= WebWrapper.connectAndGetResponse(url, reqParams, "POST");
			
			if(response !=null)
				try {
					result = new JSONObject(response);
				} catch (JSONException e) {
					Log.e("BookingActivity", e.getMessage());
				}
			
			return result;
		}
		
		@Override
		protected void onPostExecute(JSONObject result) {
			dlg.cancel();
			String status=null;
			if(result!=null)
			{
				status=ResponseFactory.getBookingStatus(BookingActivity.this, result);
				Toast.makeText(BookingActivity.this, "Status:"+status, Toast.LENGTH_LONG).show();
				if(!ResponseFactory.error) {
					setColor(slotNo, true);
					BookingManager.setAlarm(getApplicationContext(),startH, startM);
				}
			}
				
		}
		
	}
	private class BookingStatus extends AsyncTask<Integer, Void, JSONObject>
	{

		@Override
		protected JSONObject doInBackground(Integer... params) {
			
			JSONObject result=null;
			int type = params[0];
			int level = params[1];
			
			String typeS = WebWrapper.getTypeCode(type);
			
			
			String levelS = WebWrapper.getLevelCode(level);
			
			
			String url = WebWrapper.urlS +"/"+levelS+"/"+typeS;
			
			String response= WebWrapper.connectAndGetResponse(url, null, "GET");
			
			if(response !=null)
				try {
					result = new JSONObject(response);
				} catch (JSONException e) {
					Log.e("BookingActivity", e.getMessage());
				}
			
			return result;
		}
		
		@Override
		protected void onPostExecute(JSONObject result) {
			dlg.cancel();
			if(result!=null)
			{
				ResponseFactory.getBooking(result,areaCode);
				setColor();
			}
		}
		
	}
	
	private void setColor() {
		Button slotB = null;
		int area_index = BookingManager.adjustIndex(areaCode);
		for (int i = 1; i <= 8; i++) {
			switch (i) {
			case 1:
				slotB = slot1;
				break;
			case 2:
				slotB = slot2;
				break;
			case 3:
				slotB = slot3;
				break;
			case 4:
				slotB = slot4;
				break;
			case 5:
				slotB = slot5;
				break;
			case 6:
				slotB = slot6;
				break;
			case 7:
				slotB = slot7;
				break;
			case 8:
				slotB = slot8;
				break;
			}

			boolean isBooked = BookingManager.isAvailable(i+area_index,areaCode);
			if (!isBooked)
				slotB.setBackgroundResource(R.color.booked);
			else
				slotB.setBackgroundResource(R.color.available);
		}
	}
	private void setColor(int slot, boolean isBooked)
	{
		Button slotB=null;
		int area_index = BookingManager.adjustIndex(areaCode);
		slot= slot-area_index;
		switch(slot)
		{
		case 1:
			slotB = slot1;
			break;
		case 2:
			slotB = slot2;
			break;
		case 3:
			slotB = slot3;
			break;
		case 4:
			slotB = slot4;
			break;
		case 5:
			slotB = slot5;
			break;
		case 6:
			slotB = slot6;
			break;
		case 7:
			slotB = slot7;
			break;
		case 8:
			slotB = slot8;
			break;
		}
		
		if(isBooked)
			slotB.setBackgroundResource(R.color.booked);
		else
			slotB.setBackgroundResource(R.color.available);
	}

	public void doBooking(View v)
	{
		
		vehicleNo= vehicleE.getText().toString();

		
		if(vehicleNo.length()>0)
		{
			
			slotNo=Integer.parseInt(((Button) v).getText().toString());
			/*int slotB = v.getId();
			switch(slotB)
			{
			case R.id.button1:
				//slotNo =1;
				slotNo = Integer.parseInt(slot1.getText().toString());
				break;
			case R.id.button2:
				slotNo =2;
				break;
			case R.id.button3:
				slotNo =3;
				break;
			case R.id.button4:
				slotNo =4;
				break;
			case R.id.button5:
				slotNo =5;
				break;
			case R.id.button6:
				slotNo =6;
				break;
			case R.id.button7:
				slotNo =7;
				break;
			case R.id.button8:
				slotNo =8;
				break;
			}*/
			
			//check type of slot, clicked
			if(BookingManager.isAvailable(slotNo,areaCode))
			{
		TimePickerDialog dlg = new TimePickerDialog(this, this, 8, 0, true);
		dlg.setTitle("Select time");
		dlg.show();
			}
			else
			{
				Intent i = new Intent(this, BookingOverlapActivity.class);
				i.putExtra("type", type);
				i.putExtra("level", level);
				i.putExtra("slot", slotNo);
				i.putExtra("vehicle", vehicleNo);
				i.putExtra("mobile", mobileNo);
				i.putExtra("area",areaCode);
				startActivity(i);
			}
		}
		else
			Toast.makeText(this, "Pls enter vehicle number", Toast.LENGTH_LONG).show(); 
	}

	private int bookingHod, bookingMM;
	@Override
	public void onTimeSet(TimePicker view, int hod, int mm) {
		
		 if (view.isShown()) {
		int currentH= Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		int currentM = Calendar.getInstance().get(Calendar.MINUTE);
		
		if(hod> currentH)
		{
			int diff = hod - currentH;
			if(diff>4)
				Toast.makeText(this, "Pls book 4hours before", Toast.LENGTH_LONG).show();
			else 
			{
				//do booking
				// display payment
				bookingHod=hod;
				bookingMM =mm;
				displayPayment();
				/*dlg = ProgressDialog.show(BookingActivity.this, "", "Pls wait; Booking is in progress");
				BookingTask task = new BookingTask(vehicleNo, mobileNo, hod, mm, 0, 0);
				//BookingTask task = new BookingTask(vehicleNo, mobileNo, hod, mm, hod+duration, mm);

				task.execute(level, type, slotNo);*/
			}
		}
		
		else
		{
			Toast.makeText(this, "Invalid booking time", Toast.LENGTH_LONG).show();
		}
		 }
		
	}

	private Dialog displayPayment() {
		LayoutInflater factory = LayoutInflater.from(this);
		final View textEntryView = factory.inflate(R.layout.pay_dialog,
				null);
		final EditText numberE = (EditText) textEntryView
				.findViewById(R.id.numberE);

		final EditText expiryE = (EditText) textEntryView
				.findViewById(R.id.expiryE);

		final EditText cvvE = (EditText) textEntryView
				.findViewById(R.id.cvvE);

			return new AlertDialog.Builder(this)
				.setIcon(android.R.drawable.alert_dark_frame)
				.setTitle("Enter Card details")
				.setView(textEntryView)
				.setCancelable(false)
				.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
												int whichButton) {

								/* User clicked OK so do some stuff */
								String number = numberE.getText()
										.toString();
								String cvv = cvvE.getText().toString();
								String exp = expiryE.getText().toString();

								if (number.length() <=0 || cvv.length()<=0 || exp.length() <=0 ) {

									Toast.makeText(BookingActivity.this,
											"Enter valid card details",
											Toast.LENGTH_LONG).show();

								} else {
									dialog.cancel();
									dlg = ProgressDialog.show(BookingActivity.this, "", "Pls wait; Booking is in progress");
									BookingTask task = new BookingTask(vehicleNo, mobileNo, bookingHod, bookingMM, 0, 0);
									//BookingTask task = new BookingTask(vehicleNo, mobileNo, hod, mm, hod+duration, mm);

									task.execute(level, type, slotNo);
								}
							}
						})

				.show();


	}

}
